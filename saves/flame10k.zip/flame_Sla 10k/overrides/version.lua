return {
    expgaming = '6.0.0'
}