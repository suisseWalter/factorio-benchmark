--- Lists all bonuses which can be used, name followed by min max
-- @config Bonuses

return {
    character_mining_speed_modifier={0,3},
    character_crafting_speed_modifier={0,3},
    character_running_speed_modifier={0,3},
    character_build_distance_bonus={0,20},
    character_reach_distance_bonus={0,20},
    character_inventory_slots_bonus={0,200}
}