return {
    Cooldude2606 = 'Lua lets you set metatables on numbers, did you know that? Cooldude2606 knows this.',
    samy115 = 'Tremble in fear as the banhammer is now here, its owner: samy115',
    XenoCyber = '"Fire Fire Fire" oops wrong game, have no fear XenoCyber is here',
    HunterOfGames = 'Unable to support HunterOfGames. You must construct additional miners.',
    ookl = 'ookl says: "Pineapples are amazing, hello everyone!"',
    arty714 = 'Arty\'s Potato made it!'
}